---
name: revit-exportar-cad
description: Exporta vistas y láminas de Revit a DWG/AutoCAD con las capas agrupadas por elemento de dibujo (MUROS, CARP-PUERTAS, MOBILIARIO, VEGETACION...) conservando la expresión gráfica de Revit (halftones, colores, grosores) y dejando todo BYLAYER, para que el DWG se abra sin configurar nada. Actívala cuando el usuario pida "exportar a AutoCAD", "pasar el plano a CAD", "exportar la lámina a DWG", "las capas salen superpuestas al exportar", "agrupar las capas del DWG" o similar.
---

# Revit → AutoCAD con capas agrupadas

Criterios y trampas validados contra Revit 2026 sobre modelos reales.
Hay dos caminos: el **botón pyRevit** (producción) y el **MCP** (diagnóstico
y casos a medida).

## Cuál usar

| | MCP | pyRevit |
|---|---|---|
| Investigar la API, diagnosticar una vista | **Mejor** | lento (hay que recargar) |
| Exportar en producción | cada export da **timeout** | corre en proceso, con progreso |
| Repetible por el equipo | no | **sí**, es un botón |

Regla: **MCP para diagnosticar, pyRevit para exportar.**

## 🔴 Los tres modos: elegir mal es LA causa del problema

`DWGExportOptions.PropOverrides`:

| Modo | Se ve como Revit | Obedece a la capa |
|---|---|---|
| `ByEntity` (**default de Revit**) | Sí | **No** — propiedades pegadas a la entidad |
| `ByLayer` | **No** — descarta overrides | Sí |
| **`NewLayer`** | **Sí** | **Sí** |

Cuando el usuario dice *"las capas se superponen"* o *"cambio la capa y no
pasa nada"*, casi siempre está exportando en `ByEntity`.

`NewLayer` crea capas `-1`/`-2` con el override horneado en la capa. **No
son un error**: son el mecanismo. Costo medido: vista suelta ~20 capas;
lámina con 8 vistas de overrides distintos → **74 capas**. Si molesta,
`ByLayer` (se pierden halftones).

## 🔴 La trampa que falla EN SILENCIO

`ExportLayerKey(cat, subcat, SpecialType)` exige **`SpecialType.Default`**.
Con un valor inválido, `ExportLayerTable.Add()` lanza excepción y —si se
traga en un try/except— Revit cae al estándar AIA: exportás y ves
`A-WALL-____-MCUT` en vez de `MUROS`, **sin ningún error**.

Los muros además tienen `InteriorWall` / `ExteriorWall` / `FoundationWall`
/ `RetainingWall`: mapearlos todos o parte de los muros se escapa.

## Láminas (sheets)

- `MergedViews = True` es **obligatorio**: sin eso, las vistas de la hoja
  salen como XREFs externos en archivos aparte.
- Resultado correcto: **un solo DWG**, rótulo y títulos de viewport en
  **espacio papel** (capas `ROTULO`, `VIEWPORT-TITULO`, `TEXTOS`), modelo
  en espacio modelo.
- ⚠️ `DXFExportOptions` **no tiene** `MergedViews` (solo DWG): asignarlo no
  compila.

## Configuración que funciona

```
PropOverrides           = NewLayer
Colors                  = TrueColorPerView
TargetUnit              = Millimeter
FileVersion             = R2013
PreserveCoincidentLines = False     # fusiona líneas duplicadas
TextTreatment           = Exact
LineScaling             = ViewScale
MergedViews             = True      # solo DWG, clave para láminas
HideScopeBox / HideReferencePlane / HideUnreferenceViewTags = True
```

Otras: `Document.Export` **no puede correr dentro de una Transaction**. Si
el proyecto no tiene setups DWG guardados, `GetExportLayerTable()` devuelve
0 entradas y `LayerMapping` viene vacío — es normal, la tabla se construye
desde cero.

## Diagnóstico previo (MCP, read-only)

Antes de exportar, revisar en la vista activa:

- **overrides de categoría** (`v.GetCategoryOverrides`) — cuántas y cuáles
  tienen halftone: son las que van a generar capas `-1`.
- **filtros** (`v.GetFilters`) — visibilidad y overrides.
- **modo temporal** `v.IsInTemporaryViewMode(TemporaryViewMode.TemporaryHideIsolate)`
  — si está activo, el export no respeta lo que se ve en pantalla.
- **vínculos y CAD importados** visibles (`RevitLinkInstance`,
  `ImportInstance`) — ensucian el DWG.
- **rango de vista** en plantas: si arrastra elementos ajenos, ajustar
  plano de corte.

## ✅ Verificación obligatoria

Nunca dar por buena una exportación porque devolvió `True`. Exportar un
**DXF gemelo** con la misma config y auditarlo con `ezdxf`:

```python
import ezdxf, collections
doc = ezdxf.readfile(RUTA_DXF)
uso = collections.Counter(); propio = 0
for e in doc.modelspace():
    uso[e.dxf.layer] += 1
    if e.dxf.hasattr("color") and e.dxf.color != 256:
        propio += 1
print("unidades:", doc.header.get("$INSUNITS"), "(4=mm)")
print("capas:", len(uso), "| color propio (debe ser 0):", propio)
for lay, n in uso.most_common():
    print("  %-28s %6d" % (lay, n))
```

Qué mirar:
- **entidades con `color != 256` → deben ser 0** (256 = BYLAYER).
- nombres de capa: ¿agrupados o AIA? Si son AIA, el mapeo no se aplicó.
- `$INSUNITS` = 4 (mm).
- láminas: recorrer `doc.layouts` y confirmar rótulo + viewports en papel.
- que **no** se hayan generado DWG satélite (serían XREFs).

## 🚫 Trampas del MCP confirmadas

- Los exports dan **timeout** pero **el trabajo se completa igual**:
  verificar en disco antes de reintentar (y esperar a que el archivo deje
  de crecer, los DXF pueden ser de 50–100 MB).
- El MCP a veces devuelve **la respuesta de la llamada anterior**
  (desfasaje de uno). No confiar en la respuesta: confiar en el archivo.
- `ElementId.IntegerValue` no existe en 2026 → usar `.Value`.

## Lo que NO hace

No juzga si el plano "lee bien". El control visual final es del
arquitecto. El criterio de agrupación de capas es de oficina: vive en
`cad/mapeo_capas_export.json` y se edita sin tocar código.
