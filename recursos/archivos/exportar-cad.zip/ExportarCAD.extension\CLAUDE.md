# Instrucciones para Claude Code — Exportar de Revit a AutoCAD

Este paquete es una extensión de pyRevit que exporta vistas y láminas de
Revit a DWG **con las capas agrupadas por elemento de dibujo** (MUROS,
CARP-PUERTAS, MOBILIARIO, VEGETACION...) y conservando la expresión
gráfica de Revit, de modo que el DWG se abra en AutoCAD sin tener que
configurar nada.

Si el usuario te pide ayuda con esto, tu trabajo es: **instalarlo,
explicarle cómo usarlo, y ajustarle la agrupación de capas si la necesita
distinta.** Todo lo que sigue ya está verificado contra Revit 2026 — no
hace falta que lo redescubras.

---

## 1. Instalación (hacela vos, no se la dictes al usuario)

Requisitos: Revit (2020–2026) y pyRevit (gratis, https://pyrevitlabs.io).
**No requiere Python instalado ni conexión a internet** para usar el botón.

Pasos:

1. Copiá la carpeta `ExportarCAD.extension` completa a una ubicación
   estable del usuario, por ejemplo `C:\Users\<usuario>\pyRevitExtensions\`.
   **Nunca** dentro de la carpeta de instalación de pyRevit
   (`...\AppData\Roaming\pyRevit-Master\extensions`): se pisa al actualizar.

2. Registrá la carpeta PADRE en pyRevit con el CLI:

   ```bash
   pyrevit extensions paths add "C:\Users\<usuario>\pyRevitExtensions"
   ```

   Verificá que quedó registrada:

   ```bash
   pyrevit extensions paths
   ```

   Tiene que aparecer bajo `==> Extension Search Paths`.

3. Decile al usuario que abra Revit (o pyRevit → Reload si ya está
   abierto). Aparece la pestaña **Exportar** con el botón **Exportar CAD**.

> ⚠️ **No edites `pyRevit_config.ini` a mano.** La clave `userextensions`
> va en la sección `[core]`, no en `[environment]`; si la ponés mal,
> pyRevit ignora la carpeta sin dar ningún error. Usá el CLI.

Si el CLI no está en el PATH, suele estar en
`C:\Program Files\pyRevit-Master\bin\pyrevit.exe`.

---

## 2. Cómo se usa (explicáselo al usuario)

**Exportar → Exportar CAD** pregunta, en orden:

1. **Qué exportar**: Láminas (la presentación con las vistas adentro),
   Vistas sueltas, o Ambas.
2. **Cuáles**: lista multiselección. Las láminas se muestran como
   `LAMINA 00 - PRESENTACION V01 (8 vistas)`.
3. **Carpeta de destino**.

Genera un DWG por lámina/vista y muestra un reporte con qué se exportó,
el tamaño de cada archivo y qué categorías no pudo mapear.

**En AutoCAD no hay que configurar nada.** Lo único: si no se ven los
grosores de línea, activar `LWDISPLAY` (o el botón LWT de la barra de
estado) — es un toggle de visualización de AutoCAD, no falta nada en el
archivo.

---

## 3. Ajustar la agrupación de capas

Todo vive en [`cad/mapeo_capas_export.json`](cad/mapeo_capas_export.json).
Se edita con un bloc de notas y con **pyRevit → Reload** ya toma el cambio.
No hay que tocar Python.

Cada grupo es:

```json
{ "capa": "MUROS", "color": 7, "categorias": ["Walls"] }
```

- `capa`: el nombre de capa que va a aparecer en AutoCAD.
- `color`: color ACI (1 rojo, 2 amarillo, 3 verde, 4 cian, 7 blanco/negro,
  8 gris...). Solo aplica a las capas sin override.
- `categorias`: nombres de categoría de Revit **en inglés** — es el nombre
  interno, funciona igual con Revit en español. Las categorías que no
  existan en el proyecto se ignoran solas.

Vienen 36 grupos y 99 categorías mapeadas, incluyendo lo de lámina
(`ROTULO`, `VIEWPORT-TITULO`, `ETIQUETAS`, `REVISIONES`, `PLANILLAS`).

Si el usuario quiere un agrupamiento distinto (por ejemplo separar
mobiliario fijo de suelto, o dividir carpinterías por familia), editá este
JSON. Si no sabés a qué categoría de Revit pertenece algo, averigualo
contra el modelo abierto en vez de adivinar (ver sección 5).

---

## 4. Lo que tenés que saber sí o sí (verificado, no lo redescubras)

### Los tres modos de exportación son un trade-off

`DWGExportOptions.PropOverrides` acepta tres valores y **elegir mal es la
causa clásica de "las capas se ven superpuestas / no obedecen"**:

| Modo | Se ve como Revit | Controlable por capa |
|---|---|---|
| `ByEntity` (**el default de Revit**) | Sí | **No** — pega color y grosor a cada entidad |
| `ByLayer` | **No** — descarta los overrides de la vista | Sí |
| **`NewLayer`** (lo que usa este botón) | **Sí** | **Sí** |

`NewLayer` conserva la expresión gráfica creando capas con sufijo `-1`,
`-2` que llevan el override horneado **en la capa**, dejando todo BYLAYER.
Las capas `-1`/`-2` **no son un error** — si el usuario se queja de "capas
de más", explicale esto antes de cambiar nada.

Costo real medido: una vista suelta da ~20 capas; una lámina con 8 vistas
que tienen overrides distintos entre sí dio **74 capas**. Si el usuario
prefiere menos capas y resigna los halftones, cambiá `modo_overrides` a
`ByLayer` en el JSON.

### La trampa que hace fallar el mapeo EN SILENCIO

`ExportLayerKey(categoria, subcategoria, SpecialType)` **exige un
`SpecialType` válido**: hay que pasar **`SpecialType.Default`**. Con
cualquier otro valor, `ExportLayerTable.Add()` lanza excepción; si eso se
traga en un `try/except`, Revit cae al estándar AIA y **exportás viendo
`A-WALL-____-MCUT` en lugar de `MUROS`, sin ningún mensaje de error**.

Los muros además admiten `InteriorWall`, `ExteriorWall`, `FoundationWall`
y `RetainingWall`: hay que mapearlos todos o parte de los muros se escapa.
El script ya lo hace.

### Láminas

`DWGExportOptions.MergedViews = True` es **obligatorio** para láminas: sin
eso Revit exporta las vistas de la hoja como XREFs externos en archivos
aparte. Con `True` sale un único DWG autocontenido, con el rótulo y los
títulos de viewport en **espacio papel** y el modelo en espacio modelo.

⚠️ `DXFExportOptions` **no tiene** `MergedViews` (solo DWG) — asignarlo da
error de compilación.

### Otras

- `Document.Export` **no puede correr dentro de una `Transaction`**.
- Resto de opciones que usa el botón: `Colors = TrueColorPerView`,
  `TargetUnit = Millimeter`, `FileVersion = R2013`,
  `PreserveCoincidentLines = False` (fusiona líneas duplicadas),
  `TextTreatment = Exact`, `LineScaling = ViewScale`.
- Si el proyecto no tiene ningún setup DWG guardado,
  `GetExportLayerTable()` devuelve **0 entradas** y `LayerMapping` viene
  vacío. Es normal: el script construye la tabla desde cero.

---

## 5. Cómo verificar que salió bien (hacelo, no lo asumas)

Nunca confíes en que el export salió bien porque devolvió `True`. El
método que funciona:

1. Exportá **además** un DXF gemelo de lo mismo, con la misma config.
2. Leelo con `ezdxf` (`pip install ezdxf`) y chequeá:
   - **entidades con `dxf.color != 256` → tienen que ser 0** (256 =
     BYLAYER). Si hay más de 0, el modo de override está mal.
   - la lista de capas reales: ¿tienen los nombres agrupados o los AIA?
     Si salieron los AIA, el mapeo no se aplicó (ver la trampa del
     `SpecialType`).
   - `$INSUNITS` debe ser 4 (milímetros).
   - para láminas: recorré `doc.layouts` — el espacio papel debe tener el
     rótulo en `ROTULO` y los viewports.

Script de auditoría de referencia:

```python
import ezdxf, collections
doc = ezdxf.readfile(RUTA_DXF)
capas = {l.dxf.name: l for l in doc.layers}
uso = collections.Counter(); propio = 0
for e in doc.modelspace():
    uso[e.dxf.layer] += 1
    if e.dxf.hasattr("color") and e.dxf.color != 256:
        propio += 1
print("unidades:", doc.header.get("$INSUNITS"), "(4=mm)")
print("capas usadas:", len(uso))
for lay, n in uso.most_common():
    print("  %-28s %6d" % (lay, n))
print("entidades con color propio (debe ser 0):", propio)
```

Si además tenés el **MCP de Revit** conectado, podés consultar el modelo
en vivo (`send_code_to_revit`) para diagnosticar antes de exportar: qué
overrides de categoría tiene la vista, si hay filtros, vínculos o CAD
importados, o si está activo el modo temporal Ocultar/Aislar.

> Nota sobre el MCP: cada export tarda y suele dar **timeout**, pero el
> trabajo igual se completa — verificá en disco antes de reintentar. Ese
> MCP además a veces devuelve **la respuesta de la llamada anterior**
> (desfasaje de uno): no confíes en la respuesta, confiá en el archivo.

---

## 6. Si el usuario reporta que "las capas siguen mal"

Diagnosticá en este orden:

1. ¿Salieron nombres AIA (`A-WALL-____-MCUT`) en vez de los agrupados?
   → El mapeo no se aplicó. Revisá el `SpecialType` y que los nombres de
   categoría del JSON estén **en inglés y bien escritos**.
2. ¿Los objetos no obedecen a su capa en AutoCAD?
   → El modo quedó en `ByEntity`. Revisá `modo_overrides` en el JSON.
3. ¿Hay demasiadas capas `-1`, `-2`, `-3`?
   → Es `NewLayer` funcionando. Es el precio de la fidelidad visual;
   ofrecé cambiar a `ByLayer`.
4. ¿La lámina abrió con archivos XREF aparte?
   → `fusionar_vistas_en_lamina` está en `false` en el JSON.
5. ¿Aparece basura de otras partes del modelo?
   → La vista tiene el modo temporal Ocultar/Aislar activo, o hay
   vínculos/CAD importados visibles. Se diagnostica con el MCP o
   mirando la vista en Revit.
