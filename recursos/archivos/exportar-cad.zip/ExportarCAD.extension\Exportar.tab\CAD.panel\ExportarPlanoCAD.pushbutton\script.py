# -*- coding: utf-8 -*-
"""Exporta vistas a DWG con las capas AGRUPADAS POR ELEMENTO de dibujo.

En vez de las capas del estandar AIA (A-WALL-____-MCUT, I-FURN-____-OTLN),
genera capas con nombres de obra: MUROS, CARP-PUERTAS, CARP-VENTANAS,
MOBILIARIO, MESADAS, SANITARIOS, VEGETACION, PISOS, REGIONES-RELLENAS...
La agrupacion se edita en cad\\mapeo_capas_export.json, sin tocar codigo.

Claves tecnicas descubiertas contra la API (Revit 2026):
- ExportLayerKey EXIGE un SpecialType valido: hay que pasar
  SpecialType.Default. Con cualquier otro valor, Add() lanza excepcion y
  Revit cae en silencio al estandar AIA (el sintoma es exportar y ver los
  nombres de siempre).
- Los muros ademas admiten InteriorWall / ExteriorWall / FoundationWall /
  RetainingWall: hay que mapearlos todos o parte de los muros se escapa.
- PropOverrides = NewLayer conserva la expresion grafica de la vista
  (halftones, colores) creando capas -1/-2 con esas propiedades horneadas,
  y deja TODO en BYLAYER (nada de propiedades pegadas a la entidad).
- Document.Export NO puede correr dentro de una Transaction.
"""

__title__ = 'Exportar\nCAD'
__doc__ = ('Exporta las vistas elegidas a DWG con las capas agrupadas por '
           'elemento (MUROS, CARP-PUERTAS, MOBILIARIO, VEGETACION...) '
           'conservando la expresion grafica de Revit y dejando todo '
           'BYLAYER. La agrupacion se edita en cad/mapeo_capas_export.json.')

import io
import json
import os

from pyrevit import revit, DB, forms, script
from System.Collections.Generic import List

doc = revit.doc
output = script.get_output()

CARPETA_CAD = os.path.normpath(os.path.join(
    os.path.dirname(__file__), '..', '..', '..', 'cad'))
RUTA_MAPEO = os.path.join(CARPETA_CAD, 'mapeo_capas_export.json')

TIPOS_MURO = ['InteriorWall', 'ExteriorWall',
              'FoundationWall', 'RetainingWall']


def cargar_mapeo():
    if not os.path.exists(RUTA_MAPEO):
        forms.alert('No se encontro el mapeo de capas:\n{}'.format(RUTA_MAPEO),
                    title='Exportar CAD', exitscript=True)
    with io.open(RUTA_MAPEO, 'r', encoding='utf-8') as f:
        return json.load(f)


def construir_tabla(mapeo):
    """ExportLayerTable con una capa por grupo. Devuelve (tabla, ok, fallos)."""
    por_categoria = {}
    for g in mapeo['grupos']:
        for cat in g['categorias']:
            por_categoria[cat] = (g['capa'], int(g.get('color', 7)))

    sufijo = mapeo.get('opciones', {}).get('sufijo_corte', '-CORTE')
    tabla = DB.ExportLayerTable()
    ok = 0
    fallos = []

    def info_de(capa, color):
        i = DB.ExportLayerInfo()
        i.LayerName = capa
        i.ColorNumber = color
        i.CutLayerName = capa + sufijo
        i.CutColorNumber = color
        return i

    for cat in doc.Settings.Categories:
        try:
            nombre = cat.Name
        except Exception:
            continue
        if nombre not in por_categoria:
            continue
        capa, color = por_categoria[nombre]

        # clave principal (SpecialType.Default es obligatorio)
        try:
            tabla.Add(DB.ExportLayerKey(nombre, '', DB.SpecialType.Default),
                      info_de(capa, color))
            ok += 1
        except Exception as e:
            fallos.append('{}: {}'.format(nombre, str(e)[:60]))

        # los muros tienen tipos especiales propios
        if nombre == 'Walls':
            for tn in TIPOS_MURO:
                st = getattr(DB.SpecialType, tn, None)
                if st is None:
                    continue
                try:
                    tabla.Add(DB.ExportLayerKey(nombre, '', st),
                              info_de(capa, color))
                    ok += 1
                except Exception:
                    pass

        # subcategorias -> misma capa del grupo
        try:
            if cat.SubCategories:
                for sc in cat.SubCategories:
                    try:
                        tabla.Add(
                            DB.ExportLayerKey(nombre, sc.Name,
                                              DB.SpecialType.Default),
                            info_de(capa, color))
                        ok += 1
                    except Exception:
                        pass
        except Exception:
            pass

    return tabla, ok, fallos


def aplicar_opciones(opts, tabla, op):
    opts.SetExportLayerTable(tabla)
    modo = op.get('modo_overrides', 'NewLayer')
    opts.PropOverrides = getattr(DB.PropOverrideMode, modo,
                                 DB.PropOverrideMode.NewLayer)
    colores = op.get('colores', 'TrueColorPerView')
    opts.Colors = getattr(DB.ExportColorMode, colores,
                          DB.ExportColorMode.TrueColorPerView)
    unidad = op.get('unidades', 'Millimeter')
    opts.TargetUnit = getattr(DB.ExportUnit, unidad, DB.ExportUnit.Millimeter)
    version = op.get('version_dwg', 'R2013')
    opts.FileVersion = getattr(DB.ACADVersion, version, DB.ACADVersion.R2013)
    opts.TextTreatment = DB.TextTreatment.Exact
    opts.LineScaling = DB.LineScaling.ViewScale
    opts.PreserveCoincidentLines = False   # fusiona lineas duplicadas
    opts.HideScopeBox = True
    opts.HideReferencePlane = True
    opts.HideUnreferenceViewTags = True
    opts.ExportingAreas = False
    opts.SharedCoords = False
    # CRITICO para laminas: True = un unico DWG autocontenido.
    # False = Revit saca las vistas de la lamina como XREFs externos.
    opts.MergedViews = bool(op.get('fusionar_vistas_en_lamina', True))
    return opts


# ----------------------------------------------------- 1. que exportar
que = forms.ask_for_one_item(
    ['Laminas (presentacion con las vistas adentro)',
     'Vistas sueltas',
     'Ambas'],
    default='Laminas (presentacion con las vistas adentro)',
    prompt='Que queres exportar a DWG',
    title='Exportar CAD')
if not que:
    script.exit()
quiere_laminas = que.startswith('Laminas') or que == 'Ambas'
quiere_vistas = que.startswith('Vistas') or que == 'Ambas'

candidatas = []

if quiere_laminas:
    for h in DB.FilteredElementCollector(doc).OfClass(DB.ViewSheet):
        try:
            if h.IsTemplate:
                continue
            n_vistas = 0
            try:
                n_vistas = len(h.GetAllPlacedViews())
            except Exception:
                pass
            etiqueta = 'LAMINA  {} - {}  ({} vistas)'.format(
                h.SheetNumber, h.Name, n_vistas)
            candidatas.append((h, etiqueta, 'lamina'))
        except Exception:
            pass

if quiere_vistas:
    for v in DB.FilteredElementCollector(doc).OfClass(DB.View):
        try:
            if v.IsTemplate or isinstance(v, DB.ViewSheet):
                continue
            if v.ViewType not in (DB.ViewType.FloorPlan,
                                  DB.ViewType.CeilingPlan,
                                  DB.ViewType.Section, DB.ViewType.Elevation,
                                  DB.ViewType.DraftingView,
                                  DB.ViewType.EngineeringPlan,
                                  DB.ViewType.Legend):
                continue
            candidatas.append((v, 'VISTA   {} [{}]'.format(
                DB.Element.Name.__get__(v), v.ViewType), 'vista'))
        except Exception:
            pass

if not candidatas:
    forms.alert('No hay laminas ni vistas exportables en el proyecto.',
                title='Exportar CAD', exitscript=True)
candidatas.sort(key=lambda x: x[1])

etiquetas = [n for _, n, _ in candidatas]
elegidas = forms.SelectFromList.show(
    etiquetas,
    title='Laminas / vistas a exportar a DWG',
    multiselect=True,
    button_name='Exportar',
)
if not elegidas:
    script.exit()
seleccion = [(v, n, k) for v, n, k in candidatas if n in elegidas]

carpeta = forms.pick_folder(title='Carpeta de destino del DWG')
if not carpeta:
    script.exit()

# ------------------------------------------------------- 2. tabla de capas
mapeo = cargar_mapeo()
tabla, n_ok, fallos = construir_tabla(mapeo)
if n_ok == 0:
    forms.alert('No se pudo construir la tabla de capas.\n'
                'Revisar los nombres de categoria en\n{}'.format(RUTA_MAPEO),
                title='Exportar CAD', exitscript=True)

# ------------------------------------------------------------ 3. exportar
resultados = []
op = mapeo.get('opciones', {})
proyecto = os.path.splitext(
    os.path.basename(doc.PathName or 'proyecto'))[0]

with forms.ProgressBar(title='Exportando ({value} de {max_value})') as pb:
    for i, (v, etiqueta, clase) in enumerate(seleccion):
        pb.update_progress(i, len(seleccion))
        if clase == 'lamina':
            titulo = '{} - {}'.format(v.SheetNumber, v.Name)
            base = '{}_LAM_{}'.format(proyecto, titulo)
        else:
            titulo = DB.Element.Name.__get__(v)
            base = '{}_{}'.format(proyecto, titulo)
        for ch in '\\/:*?"<>|.':
            base = base.replace(ch, '-')
        try:
            opts = aplicar_opciones(DB.DWGExportOptions(), tabla, op)
            ids = List[DB.ElementId]()
            ids.Add(v.Id)
            ok = doc.Export(carpeta, base, ids, opts)
            ruta = os.path.join(carpeta, base + '.dwg')
            tam = 0
            if os.path.exists(ruta):
                tam = os.path.getsize(ruta) / 1024.0
            # si quedaron XREFs, la lamina NO es autocontenida: avisar
            aviso = ''
            if clase == 'lamina' and not opts.MergedViews:
                aviso = '  OJO: exportada con XREFs externos'
            resultados.append((clase, titulo, 'OK' if ok else 'FALLO',
                               '{} ({:.0f} KB){}'.format(base + '.dwg',
                                                         tam, aviso)))
        except Exception as e:
            resultados.append((clase, titulo, 'ERROR', str(e)[:120]))
    pb.update_progress(len(seleccion), len(seleccion))

# ------------------------------------------------------------- 4. reporte
output.print_md('# Exportacion a CAD - resultado')
output.print_md('**Carpeta:** {}'.format(carpeta))
output.print_md('**Modo:** {} | **Colores:** {} | **Unidades:** {} | '
                '**Version:** {}'.format(
                    op.get('modo_overrides', 'NewLayer'),
                    op.get('colores', 'TrueColorPerView'),
                    op.get('unidades', 'Millimeter'),
                    op.get('version_dwg', 'R2013')))
output.print_md('**Entradas en la tabla de capas:** {}'.format(n_ok))

grupos = [g['capa'] for g in mapeo['grupos']]
output.print_md('**Grupos de capa:** {}'.format(', '.join(grupos)))

output.print_md('**Fusionar vistas en la lamina:** {}'.format(
    'SI (DWG autocontenido)'
    if op.get('fusionar_vistas_en_lamina', True)
    else 'NO (XREFs externos)'))

output.print_table(
    table_data=[[c, t, e, d] for c, t, e, d in resultados],
    columns=['Tipo', 'Lamina / Vista', 'Estado', 'Archivo'])

if fallos:
    output.print_md('## Categorias que no se pudieron mapear')
    for f in fallos:
        output.print_md('- {}'.format(f))

output.print_md('---')
output.print_md('*Las capas terminadas en `-1` / `-2` son las variantes con '
                'override de la vista (halftone, color): asi se conserva la '
                'expresion grafica de Revit manteniendo todo BYLAYER. Si '
                'preferis una sola capa por grupo sin overrides, cambia '
                '`modo_overrides` a `ByLayer` en el JSON de mapeo.*')
output.print_md('*En una lamina, el rotulo va a la capa `ROTULO`, los '
                'titulos de viewport a `VIEWPORT-TITULO`, y el contenido '
                'de cada vista a sus capas de elemento. El DWG abre con la '
                'lamina en espacio papel y el modelo en espacio modelo.*')

ok_n = len([r for r in resultados if r[2] == 'OK'])
forms.alert('Exportadas {} de {} laminas/vistas.\n\nCarpeta:\n{}'.format(
    ok_n, len(seleccion), carpeta), title='Exportar CAD')
