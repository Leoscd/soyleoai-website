@echo off
rem Registra esta extension en pyRevit (agrega la carpeta PADRE al search path)
setlocal
set "EXTDIR=%~dp0"
for %%I in ("%EXTDIR:~0,-1%") do set "PARENT=%%~dpI"
set "PARENT=%PARENT:~0,-1%"

set "PYREVIT="
where pyrevit >nul 2>&1
if not errorlevel 1 set "PYREVIT=pyrevit"
if not defined PYREVIT (
    if exist "C:\Program Files\pyRevit-Master\bin\pyrevit.exe" set "PYREVIT=C:\Program Files\pyRevit-Master\bin\pyrevit.exe"
)
if not defined PYREVIT (
    echo.
    echo No se encontro pyRevit en esta PC.
    echo Instalalo desde https://pyrevitlabs.io y volve a ejecutar este archivo.
    echo.
    echo Alternativa manual: en Revit, pyRevit ^> Settings ^>
    echo Custom Extension Directories ^> Add Folder ^> "%PARENT%" ^> Save ^> Reload
    echo.
    pause
    exit /b 1
)

echo Registrando "%PARENT%" en pyRevit...
"%PYREVIT%" extensions paths add "%PARENT%"
echo.
echo Verificacion (tiene que aparecer bajo "Extension Search Paths"):
"%PYREVIT%" extensions paths
echo.
echo Listo. Abri Revit (o pyRevit ^> Reload): aparece la pestana "Exportar".
pause
