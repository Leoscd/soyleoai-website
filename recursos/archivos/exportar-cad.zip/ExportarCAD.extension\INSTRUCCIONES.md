# Exportar CAD — de Revit a AutoCAD sin configurar nada

Exporta vistas y **láminas completas** de Revit a DWG con las capas
agrupadas por elemento de dibujo (MUROS, CARP-PUERTAS, MOBILIARIO,
VEGETACION, PISOS...) conservando la expresión gráfica de Revit.

El DWG abre en AutoCAD listo: colores, halftones y grosores correctos, y
todo BYLAYER para que puedas controlarlo desde el administrador de capas.

---

## La forma más fácil de instalarlo

Abrí **Claude Code** en la carpeta de este paquete y pedile:

> instalá esta extensión de pyRevit en mi Revit

El archivo `CLAUDE.md` que viene acá adentro tiene todas las instrucciones
para que lo haga solo, incluida la parte que se hace mal seguido (registrar
la carpeta con el CLI de pyRevit y no editando el .ini a mano).

---

## Instalación a mano

**Requisitos:** Revit 2020–2026 y pyRevit (gratis, https://pyrevitlabs.io).
No hace falta Python ni internet para usar el botón.

1. Copiá la carpeta `ExportarCAD.extension` completa a una carpeta tuya,
   por ejemplo `C:\Users\TU_USUARIO\pyRevitExtensions\`.
   **No** la pongas dentro de la instalación de pyRevit: se pisa al
   actualizar.

2. Doble clic en `instalar.bat` (registra la carpeta en pyRevit).
   O a mano: en Revit → pyRevit → Settings → *Custom Extension
   Directories* → **Add Folder** → elegí la carpeta **padre** →
   Save Settings → Reload.

3. Abrí Revit. Aparece la pestaña **Exportar** con el botón
   **Exportar CAD**.

---

## Cómo se usa

1. Abrí el proyecto y tocá **Exportar → Exportar CAD**.
2. Elegí **qué** exportar: Láminas, Vistas sueltas, o Ambas.
3. Elegí **cuáles** (multiselección). Las láminas se listan como
   `LAMINA 00 - PRESENTACION V01 (8 vistas)`.
4. Elegí la **carpeta de destino**.
5. Al terminar muestra un reporte con lo exportado y el tamaño de cada
   archivo.

**En AutoCAD no configures nada.** Lo único: si no ves los grosores de
línea, activá **LWT** en la barra de estado (o escribí `LWDISPLAY` y
poné 1). Es un interruptor de visualización de AutoCAD; el archivo ya
trae los grosores.

---

## Cambiar la agrupación de capas

Abrí `cad\mapeo_capas_export.json` con el Bloc de notas. Cada grupo es
una línea así:

```json
{ "capa": "MUROS", "color": 7, "categorias": ["Walls"] }
```

- **capa**: el nombre que va a tener en AutoCAD.
- **color**: color ACI (1 rojo, 2 amarillo, 3 verde, 4 cian, 7
  blanco/negro, 8 gris).
- **categorias**: las categorías de Revit **en inglés** (es el nombre
  interno; funciona igual con Revit en español).

Guardás, hacés **pyRevit → Reload**, y ya toma el cambio. No hay que
tocar código.

Vienen 36 grupos armados, incluyendo lo de lámina: `ROTULO`,
`VIEWPORT-TITULO`, `ETIQUETAS`, `REVISIONES`, `PLANILLAS`.

---

## Preguntas frecuentes

**¿Por qué hay capas terminadas en `-1` y `-2`?**
Son las variantes con override de la vista. `MUROS` son los muros
normales, `MUROS-1` los que tienen relleno de patrón, `MUROS-2` los
halftoneados. Así es como el archivo conserva la expresión gráfica de
Revit manteniendo todo BYLAYER. **No es un error.**

**Son demasiadas capas, quiero una sola por grupo.**
En `cad\mapeo_capas_export.json` cambiá `"modo_overrides": "NewLayer"`
por `"ByLayer"`. Vas a tener una capa por grupo, pero perdés los
halftones y los colores de override de la vista.

**Una lámina con muchas vistas genera muchísimas capas.**
Es esperable: cada vista con overrides distintos genera sus variantes.
Una lámina con 8 vistas dio 74 capas. Misma solución que arriba si
preferís menos.

**La lámina abrió con archivos referenciados aparte (XREF).**
En el JSON, `"fusionar_vistas_en_lamina"` tiene que estar en `true`.

**Salieron capas con nombres raros tipo `A-WALL-____-MCUT`.**
El mapeo no se aplicó. Revisá que los nombres de categoría del JSON
estén en inglés y bien escritos. Si sigue, pedile a Claude Code que lo
diagnostique: en `CLAUDE.md` está documentada la causa técnica.

**En AutoCAD cambio el color de la capa y los objetos no cambian.**
Ese es el síntoma del modo `ByEntity`, que es el default de Revit y el
motivo por el que existe esta herramienta. Verificá que
`modo_overrides` diga `NewLayer` o `ByLayer`, nunca `ByEntity`.

---

## Para el equipo

Si varios lo van a usar y querés que compartan los mismos criterios de
capas, poné la carpeta en un disco compartido (Drive/OneDrive/servidor)
y que todos registren esa misma ruta. Al editar el JSON, el cambio le
llega a todos con un Reload.

También podés instalar la skill que viene en `skill\revit-exportar-cad\`:
copiala a `C:\Users\TU_USUARIO\.claude\skills\` y el Claude Code de cada
uno va a saber diagnosticar y ajustar exportaciones a CAD por su cuenta.
